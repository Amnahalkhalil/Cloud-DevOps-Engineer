# script to delete a CloudFormation Stack.
aws cloudformation delete-stack \
--stack-name $1